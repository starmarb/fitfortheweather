from flask import Flask, request, render_template, session, redirect, url_for
import sqlite3
from temperature import getseason, season_query
import json

app = Flask(__name__, template_folder='templates')
app.secret_key = '419project'

#--------------------------------------------------------------------------------------
#get user from database that matches account info
def authenticate_user(username, password):
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT id FROM users WHERE username = ? AND password = ?", (username, password))
    user_id = cursor.fetchone()
    connection.close()
    return user_id

#use flask's session to get user_id
def get_user_id():
    return session.get('user_id')
#--------------------------------------------------------------------------------------

#Display login page if not logged in (else render user's homepage)
@app.route('/', methods=['GET'])
@app.route('/login', methods=['GET'])
def login():
    user_id = get_user_id()
    if user_id is not None: 
        return render_template('index.html')
    return render_template('login.html')

#--------------------------------------------------------------------------------------

@app.route('/login', methods=['POST'])
def login_post():
    username = request.form['username']
    password = request.form['password']
    user_id = authenticate_user(username, password)
    if user_id is not None:
        # User is authenticated, store user_id in the session
        session['user_id'] = user_id[0]
        return redirect(url_for('index'))
    else:
         error_message = "Login failed. Please try again."
         return render_template('login.html', error_message=error_message)

#--------------------------------------------------------------------------------------

@app.route('/signup', methods=['GET'])
def signup():
     return render_template('signup.html')

#--------------------------------------------------------------------------------------

@app.route('/signup', methods=['POST'])
def signup_post():
    username = request.form['username']
    password = request.form['password']
    if not (username and password):
        error_message = "Please fill out all fields."
        return render_template('signup.html', error_message=error_message)
    with sqlite3.connect("database.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        if user is None:
            # Insert user input into the database
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)",
                            (username, password))
            conn.commit()
            success_message = "Account successfully created."
            return render_template('signup.html', success_message=success_message)
        else:
             error_message = "Username already taken"
             return render_template('signup.html', error_message=error_message)

#--------------------------------------------------------------------------------------
#pop out of session to logout
@app.route('/logout')
def logout():
    session.pop('user_id', default=None)
    return render_template('login.html')

#--------------------------------------------------------------------------------------

@app.route('/home', methods=['GET'])
def index():
    user_id = get_user_id()
    if user_id is None: 
        error_message = "You must be signed in to view the home webpage."
        return render_template('login.html', error_message=error_message) 
    return render_template('index.html')

#--------------------------------------------------------------------------------------


@app.route('/getseason',methods=['POST'])
def get_season_api():
    temperature = float(request.form['temperature'])  # Retrieve temperature from form data
    season = getseason(temperature)
    return season 
    
#--------------------------------------------------------------------------------------

@app.route('/getclothes',methods=['POST'])
def get_clothing_recommendations():
    temperature = float(request.form['temperature'])  # Retrieve temperature from form data
    season = getseason(temperature)
    user_id = get_user_id()
    clothing_recs = season_query(season, user_id)  #Retrive clothing items based on season (i.e. temperature)
    return clothing_recs 

#--------------------------------------------------------------------------------------

@app.route('/closet', methods=['GET'])
def closet():
    user_id = get_user_id()
    if user_id is None: 
        error_message = "You must be signed in to view the closet webpage."
        return render_template('login.html', error_message=error_message)
    with sqlite3.connect("database.db") as conn:
        cursor = conn.cursor()
    conn.commit()
    # Retrieve data from the database to display
    cursor.execute("SELECT * FROM clothes WHERE user_id = ?", (user_id,))
    all_items = cursor.fetchall()
    # Redirect to a confirmation page
    return render_template('closet.html', all_items=all_items) 

#--------------------------------------------------------------------------------------

@app.route('/add_item', methods=['POST'])
def add_item():
    if request.method == 'POST':
        user_id = get_user_id()
        img = request.form['img']
        description = request.form['description']
        item_type = request.form['type']
        seasons = request.form.getlist('season')
        colors = request.form.getlist('colors')
        # Check if all required fields are filled out (display error if not)
        if not (img, description and item_type and seasons and colors):
                error_message = "Please fill out all fields."
                return render_template('closet.html', error_message=error_message)
        color_str = ', '.join(colors)
        with sqlite3.connect("database.db") as conn:
                cursor = conn.cursor()

        # Insert user input into the database
        cursor.execute("INSERT INTO clothes (user_id, img, description, type, summer, fall, winter, spring, color) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (user_id, img, description, item_type, 'Summer' in seasons, 'Fall' in seasons, 'Winter' in seasons, 'Spring' in seasons, color_str))
        conn.commit()
        # Retrieve data from the database to display
        cursor.execute("SELECT * FROM clothes WHERE user_id = ? ORDER BY type", (user_id,))
        all_items = cursor.fetchall()
        # Redirect to a confirmation page
        for item in all_items:
            print("color for item:", item[9])
        return render_template('closet.html', all_items=all_items)
    
#--------------------------------------------------------------------------------------

@app.route('/remove_item/<int:item_id>')
def remove_item(item_id):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    # Execute SQL query to remove the item by ID
    cursor.execute("DELETE FROM clothes WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('closet'))

#--------------------------------------------------------------------------------------

# @app.route('/remove_outfit/<str:outfitname>')
# def remove_item(outfitname):
#     conn = sqlite3.connect('database.db')
#     cursor = conn.cursor()
#     # Execute SQL query to remove the item by ID
#     cursor.execute("DELETE FROM outfit WHERE outfitname = ?", (outfitname,))
#     conn.commit()
#     conn.close()
#     return redirect(url_for('favorites'))

@app.route('/remove_outfit', methods=['POST'])
def remove_outfit():
    user_id = get_user_id()
    outfit_name_to_remove = request.form['outfit_name']

    with sqlite3.connect("database.db") as conn:
        cursor = conn.cursor()

        # Remove outfit with the specified name for the user
        cursor.execute("""
            DELETE FROM outfit
            WHERE user_id = ? AND outfitname = ?
        """, (user_id, outfit_name_to_remove))

        conn.commit()

    return redirect(url_for('favorites'))

#--------------------------------------------------------------------------------------

@app.route('/saveoutfit', methods=['POST'])
def saveoutfit():
    if request.method == 'POST':
        print('Request received')
        print('Form data:', request.form)
        user_id = get_user_id()
        outfitname = request.form['outfitname']
        saveitems = request.form.getlist('senditems[]')
        print('User ID:', user_id)
        print('Outfit Name:', outfitname)
        print('Save Items:', saveitems)
        with sqlite3.connect("database.db") as conn:
            cursor = conn.cursor()
            for item in saveitems:
                cursor.execute("INSERT INTO outfit (user_id, outfitname, outfitvalue) VALUES (?, ?, ?)",
                                (user_id, outfitname, item))
                conn.commit()
        return redirect(url_for('index'))
    

@app.route('/favorites', methods=['GET'])
def favorites():
    user_id = get_user_id()
    with sqlite3.connect("database.db") as conn:
        cursor = conn.cursor()
    # Use GROUP_CONCAT to concatenate outfitvalues grouped by outfitname
    cursor.execute("""
        SELECT outfitname, GROUP_CONCAT(outfitvalue) as outfit_values
        FROM outfit
        WHERE user_id = ?
        GROUP BY outfitname
        ORDER BY outfitname
    """, (user_id,))

    outfits_data = cursor.fetchall()
    return render_template('favorites.html', outfits_data=outfits_data)
#--------------------------------------------------------------------------------------

if __name__ == '__main__':
    app.run()